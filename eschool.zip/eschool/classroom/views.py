from django.shortcuts import render,redirect
from .models import School,Admin
from django.contrib.auth import login,authenticate,logout
from django.contrib.auth.models import User

# Create your views here.

def home(request):
    return render(request,'classroom/home.html')

def s_login(request):
    return render(request,'classroom/student_login.html')

def t_login(request):
    return render(request,'classroom/teacher_login.html')

def a_login(request):
    return render(request,'classroom/admin_login.html')

def s_dash(request):
    return render(request,'classroom/dashboard.html')

def t_dash(request):
    return render(request,'classroom/t_dash.html')

def a_dash(request):
    return render(request,'classroom/a_dash.html')

def s_register(request):
    return render(request,'classroom/register_school.html')

def school_register_session(request):

    if request.method != 'GET':

        name = request.POST["s_name"]
        address = request.POST["s_addrs"]
        city = request.POST["s_city"]
        state = request.POST["s_state"]
        contact_number = request.POST["s_contct"]
        email = request.POST["s_mail"]
        password = request.POST["psw"]

        user = User.objects.create_user(username = email, email = email, password = password)
        user.save()

        login(request,user)


        school = School(name = name, email = email, address = address, 
                                        city = city, state = state, contact_number = contact_number)
        school.save()

        u = request.user
        s = School.objects.get(email = email)
        admin = Admin(user = u, school_id = s, email = email)
        admin.save()
        return render(request,'classroom/t_dash.html')

    else:
        return render(request,'classroom/register_school.html')

    
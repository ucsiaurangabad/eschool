from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name = "home"),
    path('student_login', views.s_login,name="s_login"),
    path('teacher_login',views.t_login,name="t_login"),
    path('admin_login',views.a_login,name="a_login"),
    path('dashboard',views.s_dash,name="dashboard"),
    path('teacher_dashboard',views.t_dash,name="t_dash"),
    path('admin_dashboard',views.a_dash,name="a_dash"),
    path('school_register',views.s_register,name="s_register"),
    path('school_register_session',views.school_register_session,name="school_register_session"),

]